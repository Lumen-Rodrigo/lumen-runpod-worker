import pytest
from handler import JobInput, segment_frames

def test_contract_defaults():
    value = JobInput.model_validate({"video_url": "https://example.com/test.mp4", "prompt": "Apply comic style", "style": "comic"})
    assert value.preserve_audio is True and value.mode == "clip" and value.inference_steps == 24

def test_rejects_unknown_style():
    with pytest.raises(ValueError):
        JobInput.model_validate({"video_url": "https://example.com/test.mp4", "prompt": "Transform it", "style": "unknown"})

def test_segments_are_padded():
    segments = segment_frames(list(range(100)), extended=True)
    assert [count for _, count in segments] == [81, 19]
    assert all(len(segment) == 81 for segment, _ in segments)

def test_clip_rejects_long_video():
    with pytest.raises(ValueError, match="extended"):
        segment_frames(list(range(163)), extended=False)
